valid_query_params = {
	'status','role', 'pageSize', 'pageNumber', 'phoneNumber', 'email', 'facilityName',
    'facilityAddress', "firstName", "lastName", "dateOfBirth", "physicianName", 
    "pcpOrDoctor", "branch", "room", "cart", "patient", "timeToBeTaken", "dateTaken",
    "medicationName", "medicationCode", "status", "medication", "careGiver", "type"
}


